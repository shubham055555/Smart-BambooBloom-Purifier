
import serial
import csv
import time

ser = serial.Serial('COM3', 9600)  # Change COM3 as needed
filename = "air_quality_log.csv"

with open(filename, 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Timestamp", "Temp", "Humidity", "MQ135", "PM2.5"])
    print("Logging...")
    try:
        while True:
            line = ser.readline().decode().strip()
            parts = line.split(",")
            if len(parts) == 4:
                writer.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), *parts])
    except KeyboardInterrupt:
        print("Stopped.")
