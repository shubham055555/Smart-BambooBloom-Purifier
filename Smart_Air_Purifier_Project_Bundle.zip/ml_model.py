
import pandas as pd
from sklearn.linear_model import LinearRegression

df = pd.read_csv("air_quality_log.csv")
X = df[["Temp", "Humidity", "PM2.5"]]
y = df["MQ135"]

model = LinearRegression()
model.fit(X, y)

future_data = [[30, 50, 80]]
prediction = model.predict(future_data)
print("Predicted MQ135:", prediction[0])
