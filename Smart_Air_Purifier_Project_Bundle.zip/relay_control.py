
import serial

ser = serial.Serial('COM3', 9600)
predicted_value = 400

if predicted_value > 350:
    ser.write(b'1')
else:
    ser.write(b'0')
